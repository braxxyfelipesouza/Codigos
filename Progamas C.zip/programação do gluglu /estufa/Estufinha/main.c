#include <stdio.h>
#include <stdlib.h>


main()
{
    int temperatura ;
    printf("\nestufinha\n\n");
    printf("escreva a temperatura: ");
    scanf("%f, temperatura");
    if (temperatura < 20){
    printf("LIGAR AQUECEDOR")
    }else{
    }
        if (temperatura >= 20 && temperatura <=30)
         {
            printf("Operacao OK")
        }else{
                printf("Ligar resfriador");
        }
      return 0;
}
